import { Router } from 'express'
import {
  createSettings,
  deleteSettingsById,
  getCurrentSettings,
  getSettingsById,
  listSettings,
  updateCurrentSettings,
  updateSettingsById,
} from '../controllers/settingsController.js'

export const adminRouter = Router()

adminRouter.get('/settings/current', getCurrentSettings)
adminRouter.put('/settings/current', updateCurrentSettings)
adminRouter.get('/settings', listSettings)
adminRouter.post('/settings', createSettings)
adminRouter.get('/settings/:id', getSettingsById)
adminRouter.put('/settings/:id', updateSettingsById)
adminRouter.patch('/settings/:id', updateSettingsById)
adminRouter.delete('/settings/:id', deleteSettingsById)

import assert from 'node:assert/strict'

const apiBaseUrl = process.env.API_BASE_URL || 'http://127.0.0.1:5000'

async function request(path, options = {}) {
  const response = await fetch(`${apiBaseUrl}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  })

  const body = response.status === 204 ? null : await response.json()
  if (!response.ok) {
    throw new Error(`${options.method || 'GET'} ${path} failed: ${response.status} ${JSON.stringify(body)}`)
  }

  return { response, body }
}

const health = await request('/api/health')
assert.equal(health.body.status, 'ok')

const current = await request('/api/admin/settings/current')
const originalNavigation = current.body.data.topNavigation
assert.ok(Array.isArray(originalNavigation))
assert.ok(originalNavigation.length > 0)

const testNavigation = [
  { label: 'Home', link: '#home', children: [] },
  {
    label: 'Services',
    link: '#services',
    children: [{ label: 'Packaging Design', link: '#packaging-design' }],
  },
]

let createdId

try {
  const updated = await request('/api/admin/settings/current', {
    method: 'PUT',
    body: JSON.stringify({ topNavigation: testNavigation }),
  })
  assert.equal(updated.body.data.topNavigation[1].children[0].label, 'Packaging Design')

  const publicNavigation = await request('/api/settings/navigation')
  assert.equal(publicNavigation.body.topNavigation.length, 2)
  assert.equal(publicNavigation.body.topNavigation[1].children[0].link, '#packaging-design')

  const created = await request('/api/admin/settings', {
    method: 'POST',
    body: JSON.stringify({
      key: `crud-check-${Date.now()}`,
      topNavigation: [{ label: 'Temporary', link: '/temporary', children: [] }],
    }),
  })
  createdId = created.body.data._id
  assert.ok(createdId)

  const patched = await request(`/api/admin/settings/${createdId}`, {
    method: 'PATCH',
    body: JSON.stringify({
      topNavigation: [{ label: 'Updated', link: '/updated', children: [] }],
    }),
  })
  assert.equal(patched.body.data.topNavigation[0].label, 'Updated')

  const fetched = await request(`/api/admin/settings/${createdId}`)
  assert.equal(fetched.body.data.topNavigation[0].link, '/updated')

  await request(`/api/admin/settings/${createdId}`, { method: 'DELETE' })
  createdId = undefined

  console.log('Runtime API verification passed: health, seed, public navigation, create, update, read, and delete.')
} finally {
  if (createdId) {
    await request(`/api/admin/settings/${createdId}`, { method: 'DELETE' }).catch(() => {})
  }

  await request('/api/admin/settings/current', {
    method: 'PUT',
    body: JSON.stringify({ topNavigation: originalNavigation }),
  })
}

import cors from 'cors'
import express from 'express'
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js'
import { adminRouter } from './routes/adminRouter.js'
import { publicRouter } from './routes/publicRouter.js'

export function createApp() {
  const app = express()
  const allowedOrigins = (process.env.FRONTEND_ORIGIN || 'http://localhost:5173')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean)

  app.disable('x-powered-by')
  app.use(cors({ origin: allowedOrigins, credentials: true }))
  app.use(express.json({ limit: '1mb' }))

  app.get('/api/health', (_request, response) => {
    response.json({ status: 'ok', service: 'packaging-consultant-api' })
  })
  app.use('/api', publicRouter)
  app.use('/api/admin', adminRouter)
  app.use(notFoundHandler)
  app.use(errorHandler)

  return app
}
